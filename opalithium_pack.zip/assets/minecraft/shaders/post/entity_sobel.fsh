#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// opalithium: 빛나는 색의 R, G, B가 모두 8로 나눠 6이 남으면 (구역 선 표식) 테두리만이 아니라 속까지 채움
//             -> 얇은 막대가 가운데가 빈 두 줄이 아니라 한 줄의 빛나는 선으로 보임 (벽 너머로도)
bool opalFill(vec4 c) {
    if (c.a <= 0.0) return false;
    vec3 v = mod(floor(c.rgb * 255.0 + 0.5), 8.0);
    return all(equal(v, vec3(6.0)));
}

void main(){
    vec2 oneTexel = 1.0 / InSize;

    vec4 center = texture(InSampler, texCoord);
    if (opalFill(center)) {
        fragColor = vec4(center.rgb, 1.0);
        return;
    }
    vec4 left = texture(InSampler, texCoord - vec2(oneTexel.x, 0.0));
    vec4 right = texture(InSampler, texCoord + vec2(oneTexel.x, 0.0));
    vec4 up = texture(InSampler, texCoord - vec2(0.0, oneTexel.y));
    vec4 down = texture(InSampler, texCoord + vec2(0.0, oneTexel.y));
    float leftDiff  = abs(center.a - left.a);
    float rightDiff = abs(center.a - right.a);
    float upDiff    = abs(center.a - up.a);
    float downDiff  = abs(center.a - down.a);
    float total = clamp(leftDiff + rightDiff + upDiff + downDiff, 0.0, 1.0);
    vec3 outColor = center.rgb * center.a + left.rgb * left.a + right.rgb * right.a + up.rgb * up.a + down.rgb * down.a;
    fragColor = vec4(outColor * 0.2, total);
}
