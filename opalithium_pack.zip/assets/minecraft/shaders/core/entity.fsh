#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightMapColor;
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

// opalithium: 입은 갑옷의 별빛 (gen_armor_glint.py). 별 픽셀 = 등급 색 + 표시 alpha (팔 240+위상, 가운데 228+위상).
bool opalRankColor(vec3 c) {
    vec3 v = c * 255.0;
    return all(lessThan(abs(v - vec3(196.0, 155.0, 255.0)), vec3(1.5))) || all(lessThan(abs(v - vec3(255.0, 163.0, 217.0)), vec3(1.5)))
        || all(lessThan(abs(v - vec3(224.0, 80.0, 122.0)), vec3(1.5))) || all(lessThan(abs(v - vec3(255.0, 226.0, 122.0)), vec3(1.5)))
        || all(lessThan(abs(v - vec3(254.0, 254.0, 253.0)), vec3(1.5)));
}

vec3 opalHsv(float h) {
    vec3 p = abs(fract(vec3(h) + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), 0.5);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    float opalA = color.a * 255.0;
    if (opalA > 227.5 && opalA < 250.5 && opalRankColor(color.rgb)) {
        bool centre = opalA < 238.0;
        float ph = floor(centre ? opalA - 228.0 + 0.5 : opalA - 240.0 + 0.5);
        float secs = GameTime * 1200.0;                     // GameTime: 0..1 per 24000 ticks
        float k = 0.5 + 0.5 * sin(secs * 2.2 + ph * 2.39);  // each star its own time
        if (k < (centre ? 0.35 : 0.72)) discard;            // arms only near the brightest moment -> twinkle
        vec3 c = all(greaterThan(color.rgb, vec3(0.99))) ? opalHsv(fract(secs * 0.15 + ph * 0.1)) : color.rgb;
        color = vec4(centre ? mix(c, vec3(1.0), 0.65 * k) : c, 1.0);
    }
    // opalithium: 표시용 색 (254,1,253) 픽셀은 그리지 않음 -> 빛나는 테두리(outline)만 남음
    if (all(lessThan(abs(color.rgb * 255.0 - vec3(254.0, 1.0, 253.0)), vec3(1.5)))) {
        discard;
    }

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    #else
    vec4 faceVertexColor = vertexColor;
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= faceVertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
