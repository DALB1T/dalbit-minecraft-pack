#version 330
#extension GL_ARB_separate_shader_objects : require

// DALBIT: the game's own text shader (26.3) with one addition. Text drawn in the marker colour #FEFEFD (the
// "초월" rank) gets a soft rainbow that flows slowly from left to right; any other colour is drawn as before.
// Without this pack the marker colour is simply near-white, so the rank still reads as "white".

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

const vec3 MARKER = vec3(254.0, 254.0, 253.0) / 255.0;
// Opalithium 광휘: 월 #FEFEFC, 일 #FEFEFB, 명(일월) #FEFEFA, 명(天) #FEFEF9
const vec3 MOON_M = vec3(254.0, 254.0, 252.0) / 255.0;
const vec3 SUN_M = vec3(254.0, 254.0, 251.0) / 255.0;
const vec3 DUAL_M = vec3(254.0, 254.0, 250.0) / 255.0;
const vec3 SKY_M = vec3(254.0, 254.0, 249.0) / 255.0;
const vec3 MOON_A = vec3(0.80, 0.66, 1.00);  // 밝은 보라
const vec3 MOON_B = vec3(1.00, 0.93, 0.62);  // 별빛 노랑
const vec3 SUN_A = vec3(1.00, 0.58, 0.18);   // 주황
const vec3 SUN_B = vec3(1.00, 0.86, 0.30);   // 노랑

bool marked(vec3 c, vec3 m) {
    return all(lessThan(abs(c - m), vec3(0.002)));
}
const float SATURATION = 0.15; // how much colour over the white: low = soft
const float SPEED = 0.3;       // rainbows per second passing by
const float BAND = 160.0;      // screen pixels for one whole rainbow: a word of a few letters holds most of it

vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vec4 color = Color;
    if (all(lessThan(abs(Color.rgb - MARKER), vec3(0.002)))) {
        float seconds = GameTime * 1200.0;                 // GameTime: 0..1 over a day of 24000 ticks
        float px = (gl_Position.x / gl_Position.w * 0.5 + 0.5) * ScreenSize.x; // pixels from the left
        float hue = fract(px / BAND - seconds * SPEED);    // the bands move to the right as time goes on
        color = vec4(hsv2rgb(vec3(hue, SATURATION, 1.0)), Color.a);
    } else if (marked(Color.rgb, MOON_M) || marked(Color.rgb, SUN_M) || marked(Color.rgb, DUAL_M) || marked(Color.rgb, SKY_M)) {
        float t = GameTime * 1200.0;
        float px = (gl_Position.x / gl_Position.w * 0.5 + 0.5) * ScreenSize.x;
        float py = (gl_Position.y / gl_Position.w * 0.5 + 0.5) * ScreenSize.y;
        vec3 moon = mix(MOON_A, MOON_B, pow(0.5 + 0.5 * sin(px * 0.9 - t * 5.0), 6.0));   // 오른쪽으로 갈수록 별빛이 반짝이며 지나감
        vec3 sun = mix(SUN_A, SUN_B, 0.5 + 0.5 * sin(px * 0.5 - t * 2.0));
        vec3 c;
        if (marked(Color.rgb, MOON_M)) c = moon;
        else if (marked(Color.rgb, SUN_M)) c = sun;
        else if (marked(Color.rgb, DUAL_M)) c = mix(moon, sun, clamp(fract(py / 9.0) * 1.6 - 0.3, 0.0, 1.0)); // 위 일, 아래 월
        else c = mix(moon, sun, 0.5 + 0.5 * sin(py * 0.7 + t * 3.0));             // 월·일 색이 번갈아 아래에서 위로
        color = vec4(c, Color.a);
    }

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = color;
#endif
    texCoord0 = UV0;
}
