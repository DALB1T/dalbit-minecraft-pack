#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

// opalithium: 채예석 갑옷 장식 (palettes/trim/opalithium.png의 8색) -> 흐르는 무지개
vec3 opalTrimHsv(float h, float s, float v) {
    vec3 p = abs(fract(vec3(h) + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return v * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), s);
}

vec4 opalTrim(vec4 color) {
    // 채예석 장식 팔레트 8색 (gen_opal_trim.py): 정확히 이 색이면 그 밝기로 흐르는 무지개
    const vec3 OPAL[8] = vec3[8](
        vec3(246.0, 240.0, 255.0),
        vec3(226.0, 214.0, 250.0),
        vec3(206.0, 226.0, 246.0),
        vec3(190.0, 200.0, 240.0),
        vec3(170.0, 180.0, 226.0),
        vec3(150.0, 156.0, 210.0),
        vec3(126.0, 128.0, 186.0),
        vec3(98.0, 98.0, 150.0));
    vec3 v = color.rgb * 255.0;
    if (color.a > 0.5) {
        for (int i = 0; i < 8; i++) {
            if (all(lessThan(abs(v - OPAL[i]), vec3(0.6)))) {
                float level = 1.0 - float(i) / 7.0;
                float h = fract(GameTime * 1200.0 * 0.25 + (gl_FragCoord.x + gl_FragCoord.y) / 220.0);
                return vec4(opalTrimHsv(h, 0.42, 0.42 + 0.58 * level), color.a);
            }
        }
    }
    return color;
}

void main() {
    vec4 color = opalTrim(texture(Sampler0, texCoord0));
    // opalithium: 표시용 색 (254,1,253) 픽셀은 그리지 않음 -> 빛나는 테두리(outline)만 남음
    if (all(lessThan(abs(color.rgb * 255.0 - vec3(254.0, 1.0, 253.0)), vec3(1.5)))) {
        discard;
    }
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
